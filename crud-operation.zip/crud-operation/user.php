
<?php session_start();?>
<?php include"component/header.php"?>
<?php include"component/dblink.php"?>

<?php 
    $username = $_SESSION["emailoruser"] ?? '';

    $userdata = "SELECT * FROM crud_data WHERE username='$username'";
    $userdataresult = $db->query($userdata);
    $userrowdata = mysqli_fetch_assoc($userdataresult);

    $userFullname = $userrowdata['firstName'];
    $userEmail    = $userrowdata['email'];
    $userName     = $userrowdata['username'];
    $userPhone    = $userrowdata['phone'];

?>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-3 card-group bg-primary text-light">
            <div class="card-body text-center">
                <img class="" style="border-radius:50%; width:50%" src="avatar.png" alt="">
                <h4 class="mt-2">Welcome <?php echo $userFullname;?></h4>

                <div class="">
                    <img src="" alt="">
                    <table class="table text-white">
                        <thead>
                            <tr>
                                <td class=>Name:</td>
                                <td class="text-left"><?php echo $userFullname;?></td>
                            </tr>
                            <tr>
                                <td class=>User Id:</td>
                                <td class="text-left"><?php echo $userName;?></td>
                            </tr>
                            <tr>
                                <td class=>Email:</td>
                                <td class="text-left"><?php echo $userEmail;?></td>
                            </tr>
                            <tr>
                                <td class=>Phone:</td>
                                <td class="text-left"><?php echo $userPhone;?></td>
                            </tr>
                        </thead>
                    </table>
                    <div>
                        <a class="btn btn-light" href="logout.php?logout">Sign Out</a>
                    </div>
                </div>
            </div>
            
        
        </div>
        <div class="col-md-9">

            <table class="table table-hover">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Full Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">User Name</th>
                        <th scope="col">Phone Number</th>
                        <th scope="col">Password</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>

                <tbody>
                    <?php

                        $sql_query = "SELECT * FROM crud_data";
                        $result = $db-> query($sql_query);
                        // $result->num_rows> 0

                        if(isset($_SESSION["emailoruser"])==true){
                            while($row = $result->fetch_assoc()){ ?>
                                

                            <tr>
                                <th scope="row"><?php echo $row["id"] ;?></th>
                                <td><?php echo $row["firstName"] ;?></td>
                                <td><?php echo $row["email"] ;?></td>
                                <td><?php echo $row["username"] ;?></td>
                                <td><?php echo $row["phone"] ;?></td>
                                <td><?php echo $row["password"] ;?></td>
                                <td><a class="btn btn-info" href="dataupdate.php?id=<?php echo $row['id']?>">Update</a> <a class="btn btn-danger" href="delete.php?id=<?php echo $row['id']?>">Delete</a></td>
                            </tr>
                               

                           <?php }
                        }
                    
                    ?>
                    
                </tbody>
            </table>
        </div>
        <!-- <div class="col-md-1"></div> -->
    </div>
</div>

<?php include("component/footer.php");?>