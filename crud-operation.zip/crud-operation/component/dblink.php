<?php

    $dbserver    = "localhost";
    $dbuser      = "root";
    $dbpassword  = "";
    $database    = "crudoperation";

    $db = new Mysqli($dbserver,$dbuser,$dbpassword,$database );

    if($db->connect_error){

        die($db->connect_error);

    }

?>