<?php include"component/header.php"?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
        </div>
        <div class="col-md-6 bg-light card mt-5 text-center border-primary py-5">
            <h1 class="text-primary py-4 card">WELCOME TO MY PROJECT</h1>
            <h4 class="text-primary">CRUD OPERATION</h4>
            <h4 class="text-primary">BY ZAHID HASAN</h4>
            <p> <a href="login.php">login</a> Or <a href="regestration.php">Regestration</a> </p>
        </div>
        <div class="col-md-3">
        </div>
    </div>
</div>

<?php include"component/footer.php"?>