
<?php include"component/header.php"?>
<?php include"component/dblink.php"?>

<?php 

  // ---- Data view into form from Database-------

  $dynamicid = $_GET['id'];
  $select_query = "SELECT * FROM crud_data WHERE id=$dynamicid";
  $select_query_result = $db->query($select_query);
  $select_query_result->num_rows;
  $update_row = $select_query_result->fetch_assoc();

  //----Data update query----------

  $fullname   = $_POST["fname"] ?? '';
  $email      = $_POST["email"] ?? '';
  $username   = $_POST["uname"] ?? '';
  $phone      = $_POST["phone"] ?? '';
  $password   = $_POST["password"] ?? '';
  
  if(isset($_POST["update_data"]) == "Update"){

    $updatedquerydata = "UPDATE crud_data SET firstName='$fullname', email='$email', username='$username', phone='$phone', password='$password' WHERE id=$dynamicid";

    if($db->query($updatedquerydata) === true){

      $updateMsg = "Data update Successfully";
      header("location:user.php");

    }else{

      $updateMsg = "Something went wrong please try again";

    }

  }else{

    $updateMsg = "Enter your data to Update your Information";

  }
  

?>

 
<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
        </div>
        <div class="col-md-6 bg-light card mt-4">
            <div class="text-center border-bottom">
                <h1 class="text-primary"> Update Data</h1>
                <p class="text-danger"> <?php echo $updateMsg ?? '';?></p>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="fname">Full Name</label>
                        <input type="text" class="form-control" id="fname" name="fname" aria-describedby="fnameh" value="<?php echo $update_row{"firstName"};?>">
                        <small id="fnameh" class="form-text text-danger"> </small>
                    </div>
                    <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" class="form-control" id="email" name="email" aria-describedby="emailh" value="<?php echo $update_row{"email"};?>">
                        <small id="emailh" class="form-text text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="userName">User Name</label>
                        <input type="text" class="form-control" id="userName" name="uname" aria-describedby="userh" value="<?php echo $update_row{"username"};?>">
                        <small id="userh" class="form-text text-muted text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Phone Number</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" name="phone" aria-describedby="emailHelp" value="<?php echo $update_row{"phone"};?>">
                        <small id="emailHelp" class="form-text text-muted text-danger"></small>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword1" name="password" value="<?php echo $update_row{"password"};?>">
                    </div>
                    <div class=" text-center">
                        <input type="submit" class="btn btn-primary" name="update_data" value="Update">
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
</div>

<?php include"component/footer.php"?>