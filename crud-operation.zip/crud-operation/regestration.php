
<?php include"component/header.php"?>
<?php include"component/dblink.php"?>

<?php

  $fullname   = $_POST["fname"] ?? '';
  $email      = $_POST["email"] ?? '';
  $username   = $_POST["uname"] ?? '';
  $phone      = $_POST["phone"] ?? '';
  $password   = $_POST["password"] ?? '';

  

  if( isset($_POST["form_submit"]) == "Register"){
   
    if(empty($fullname)){

      $nameMsg = "Please Enter your Full Name";

    }elseif(empty($email)){

      $emailMsg = "Please Enter your vaid Email";

    }elseif(empty($username)){

      $userMsg = "Please Enter your User Name";

    }elseif(empty($phone)){

      $phoneMsg = "Please Enter your vaid Phone Number";

    }elseif(empty($password)){

      $passMsg = "Please Enter Strong Password";

    }else{

      $sql = "INSERT INTO crud_data(firstName,email,username,phone,password) VALUES ('$fullname','$email','$username','$phone','$password')";
      if($db->query($sql) == true ){

        $genMsg = '<h4 class="text-success">User Registration Successfull</h4>';

      }else{

        $genMsg = '<h4 class="text-danger">Please Try again</h4>';
      }

    }


  }else{
    $genMsg = "Please Enter your Data";


  }
  
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
        </div>
        <div class="col-md-6 bg-light card mt-4">
            <div class="text-center border-bottom">
                <h1 class="text-primary"> Registration</h1>
                <p class="text-danger"> <?php echo $genMsg ?? '';?></p>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="fname">Full Name</label>
                        <input type="text" class="form-control" id="fname" name="fname" aria-describedby="fnameh" placeholder="Enter First Name">
                        <small id="fnameh" class="form-text text-danger"> <?php echo $nameMsg ?? '' ;?> </small>
                    </div>
                    <div class="form-group">
                        <label for="email">Email address</label>
                        <input type="email" class="form-control" id="email" name="email" aria-describedby="emailh" placeholder="Enter email">
                        <small id="emailh" class="form-text text-danger"> <?php echo $emailMsg ?? '' ;?></small>
                    </div>
                    <div class="form-group">
                        <label for="userName">User Name</label>
                        <input type="text" class="form-control" id="userName" name="uname" aria-describedby="userh" placeholder="Enter User Name">
                        <small id="userh" class="form-text text-muted text-danger"> <?php echo $userMsg ?? '' ;?></small>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Phone Number</label>
                        <input type="text" class="form-control" id="exampleInputEmail1" name="phone" aria-describedby="emailHelp" placeholder="Enter Phone">
                        <small id="emailHelp" class="form-text text-muted text-danger"> <?php echo $userMsg ?? '' ;?> </small>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Password</label>
                        <input type="password" class="form-control" id="exampleInputPassword1" name="password" placeholder="Enter Password">
                    </div>
                    <div class=" text-center">
                        <input type="submit" class="btn btn-primary" name="form_submit" value="Register">
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-3"></div>
    </div>
</div>

<?php include"component/footer.php"?>