
<?php include"component/header.php"?>
<?php include"component/dblink.php"?>

<?php 
  //----Data update query----------
    $dynamicid = $_GET['id'];

    $deletequery = "DELETE FROM crud_data WHERE id=$dynamicid";

    if($db->query($deletequery) === true){

       $updateMsg = "Data Deleted Successfully";

    }else{

       $updateMsg = "Something went wrong please try again";

    }

?>


<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
        </div>
        <div class="col-md-6 bg-light card mt-4">
            <div class=" border-bottom py-4 text-center">
                <h1><?php echo $updateMsg; ?></h1>
            </div>
            <div class="card-body text-center">
                <a class="btn btn-info" href="user.php">Back to Register List</a>
            </div>
        </div>
        <div class="col-md-3">
        </div>
    </div>
</div>


<?php include"component/footer.php"?>