
<?php session_start();?>
<?php include"component/header.php"?>
<?php include"component/dblink.php"?>
<?php

    

   if(isset($_POST["loginSubmit"])){

        $emailOrUser = $_POST["emailoruser"] ?? '';
        $password = $_POST["password"] ?? '';
    
        $loginquery ="SELECT * FROM crud_data WHERE email='$emailOrUser' || username ='$emailOrUser' && password='$password'";
    
        $loginResult = $db->query($loginquery);

        $logindata = mysqli_num_rows($loginResult);

        if($logindata == 1){

            $_SESSION["emailoruser"]= $emailOrUser;
            header('location:user.php');

            $loginMsg = '<h4 class="text-success">Successfully logedin</h4>';


        }else{

            // header('location:login.php?invalid=please_input_your_valid_data');

            $loginMsg = '<h4 class="text-danger">login Failled</h4>';

        }

   }

   
?>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-3">
        </div>
        <div class="col-md-6 bg-light card mt-4">
            <div class="text-center border-bottom py-4">
                <h1 class="text-info"> Login</h1>
                <h4><?php echo $loginMsg ??'';?></h4>
            </div>
            <div class="card-body">
                <form action="" method="POST">
                    <div class="form-group">
                        <label for="exemail">Email or User Name</label>
                        <input type="text" class="form-control" id="exemail" name="emailoruser" aria-describedby="emailHelp" placeholder="Enter email or username">
                        <small id="emailHelp" class="form-text text-muted">Please enter your valid email or user name</small>
                    </div>
                    <div class="form-group">
                        <label for="expass">Password</label>
                        <input type="password" class="form-control" id="expass" name="password" placeholder="Password">
                    </div>
                    <div class=" text-center">
                        <input type="submit" class="btn btn-primary" name="loginSubmit" value="Submit">
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-3">
        </div>
    </div>
</div>

<?php include"component/footer.php"?>